#file : matlib.py
# matlib berisi library matematika sederhana :
# add, mul, sub, pow, div

def add(a,b):
	return a+b
def sub(a,b):
	return a-b
def mul(a,b):
	return a*b
def pow(a,b):
	return a ** b
def div(a,b): # pembagian dengan '/' akan menghasilkan nilai float
	return a/b
def divi(a,b): # pembagian dengan '//' akan menghasilkan nilai int
	return a//b