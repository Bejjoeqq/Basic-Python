import os,sys,math
MAXN=20

class StudentRec():
	def __init__(arg1=None,arg2=None):
		self.lastname=arg1
		self.nilai=arg2

def main():
	classStudent=[StudentRec]*MAXN
	count = 0;i=0
	count=int(input("Berapa students? "))
	if(count > MAXN):
		print("Tidak cukup ruang.\n")
		sys.exit(1)
	for i in range(count):
		classStudent[i].lastname=str(input("Masukan nama "))
		classStudent[i].Nilai=float(input("Masukan nilai "))

	print("\nDaftar kelas\n\n")
	for i in range(count):
		print("Nama : {}".format(classStudent[i].lastname))
		print("Nilai: {}".format(classStudent[i].Nilai))

if __name__=='__main__':
	main()