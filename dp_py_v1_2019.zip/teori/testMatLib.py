# file : testMatLib.py
from matlib import add,sub,pow,mul,div,divi
from Global import *

def main():
	global NILAIAWAL,PI
	a=add(2,3);print(a)
	b=sub(NILAIAWAL,4);print(b)
	c=mul(a,b);print(c)
	d=pow(2,3);print(d)
	e=div(15,2);print(e)
	f=divi(15,4);print(f)
	print(NILAIAWAL,PI)


if __name__ == '__main__':
	main()