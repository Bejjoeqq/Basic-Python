import os,sys,math
MAXN=20

class StudentRec():
	def __init__(self,arg1=None,arg2=None):
		self.lastname=arg1
		self.nilai=arg2

def printRecord(rec):
	print("Nama: {}".format(rec.lastname))
	print("Nilai:{}".format(rec.nilai))

def readRecord():
	newStudent=StudentRec()
	newStudent.lastname=str(input("Masukan nama "))
	newStudent.nilai=float(input("Masukan nilai "))
	return newStudent

def main():
	studentA=StudentRec("Gauss", 99.0)
	printRecord(studentA)

if __name__=='__main__':
	main()