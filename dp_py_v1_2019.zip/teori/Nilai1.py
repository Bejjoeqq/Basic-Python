import os,sys,math
MAXN=20
def main():
  lastname=[None]*MAXN
  Nilai=[float]*MAXN
  count = 0;i=None
  count=int(input("Berapa student? "))
  if(count> MAXN):
    print("Not enough space.\n");
    sys.exit(1);
  for i in range(count):  
    lastname[i]=str(input("nama : "))
    Nilai[i]=float(input("nilai : "))
  print("Daftar kelas\n")
  for i in range(count):
    print("Nama : {}".format(lastname[i]))
    print("Nilai: {}".format(Nilai[i]))

if __name__=='__main__':
  main()
