import os,sys,math
MAXN=20

class StudentRec():
	def __init__(self,arg1=None,arg2=None):
		self.lastname=arg1
		self.nilai=arg2

def printRecord(rec):
	print("Nama: {}".format(rec.lastname))
	print("Nilai:{}".format(rec.Nilai))

def readRecord(rec):
	rec.lastname=str(input("Masukan nama "))
	rec.Nilai=float(input("Masukan nilai "))
	return rec

def main():
	studentA=StudentRec()
	studentA=readRecord(studentA)
	printRecord(studentA)

if __name__=='__main__':
	main()