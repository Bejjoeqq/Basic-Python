import os,sys,math
MAXN=20

class StudentRec():
  def __init__(arg1=None,arg2=None):
    lastname=arg1
    nilai=arg2
def main():
  studA=StudentRec();studB=StudentRec()
  studA.lastname=str(input('Masukan Nama: '))
  studA.nilai=float(input('Masukan Nilai: '))
  studB.lastname=str(input('Masukan Nama: '))
  studB.nilai=float(input('Masukan Nilai: '))
  print("Student A:{}\t{}".format(studA.lastname,studA.nilai))
  print("Student b:{}\t{}".format(studB.lastname,studB.nilai))
if __name__=='__main__':
  main()
