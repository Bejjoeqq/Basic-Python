# File : Global.py                                
# definisi dan deklarasi variabel-varibel global 
PI=3.14
NILAIAWAL=10